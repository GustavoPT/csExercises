CREATE TRIGGER changeOnPublisherDelete
  AFTER DELETE
  ON Publisher
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Publisher',
        columnName ='publisherCode',
        oldValue = OLD.publisherCode,
        Keyval1 = OLD.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Publisher',
        columnName ='publisherName',
        oldValue = OLD.publisherName,
		Keyval1 = OLD.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Publisher',
        columnName ='City',
        oldValue = OLD.city,
        Keyval1 = OLD.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

