CREATE PROCEDURE while_loop_proc()
  BEGIN
DECLARE counter  INT;              
DECLARE str      VARCHAR(255);              
SET     counter  = 1;              
SET     str      = '';              
1_to_5_counter: WHILE counter <= 5 DO                          
    SET str = CONCAT(str,counter,',');                          
    SET counter = counter + 1;               
END WHILE 1_to_5_counter;              
SELECT LEFT(str, LENGTH(str) - 1); -- remove trailing comma
END;

