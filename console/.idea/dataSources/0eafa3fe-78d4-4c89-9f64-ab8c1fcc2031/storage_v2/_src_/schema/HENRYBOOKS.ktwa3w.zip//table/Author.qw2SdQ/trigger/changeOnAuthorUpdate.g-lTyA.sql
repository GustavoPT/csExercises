CREATE TRIGGER changeOnAuthorUpdate
  AFTER UPDATE
  ON Author
  FOR EACH ROW
  BEGIN 
				INSERT INTO HistoricalAudit
				SET Action = 'UPDATE',
				tableName = 'Author',
				columnName ='authorNum',
                oldValue  = OLD.authorNum,
				NewValue = NEW.authorNum,
				Keyval1 = NEW.authorNum,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
				
				INSERT INTO HistoricalAudit
				SET Action = 'UPDATE',
				tableName = 'Author',
				columnName ='authorLast',
                oldValue = OLD.authorLast,
				NewValue = NEW.authorLast,
				Keyval1 = NEW.authorNum,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
				
				INSERT INTO HistoricalAudit
				SET Action = 'UPDATE',
				tableName = 'Author',
				columnName ='authorFirst',
                OldValue = OLD.authorFirst,
				NewValue = NEW.authorFirst,
				Keyval1 = NEW.authorNum,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
     END;

