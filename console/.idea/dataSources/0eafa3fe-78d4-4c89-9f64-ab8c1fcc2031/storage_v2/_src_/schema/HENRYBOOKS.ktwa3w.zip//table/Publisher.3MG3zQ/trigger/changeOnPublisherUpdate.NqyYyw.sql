CREATE TRIGGER changeOnPublisherUpdate
  AFTER UPDATE
  ON Publisher
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Publisher',
        columnName ='publisherCode',
        oldValue = OLD.publisherCode,
        NewValue = NEW.publisherCode,
        Keyval1 = NEW.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Publisher',
        columnName ='publisherName',
        oldValue = OLD.publisherName,
        NewValue = NEW.publisherName,
		Keyval1 = NEW.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Publisher',
        columnName ='city',
        oldValue = OLD.city,
        NewValue = NEW.publisherCode,
        Keyval1 = NEW.city,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

