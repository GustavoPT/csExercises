CREATE TRIGGER changeOnBranchInsert
  AFTER INSERT
  ON Branch
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Branch',
        columnName ='branchNum',
        NewValue = NEW.branchNum,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Branch',
        columnName ='branchName',
        NewValue = NEW.branchName,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Branch',
        columnName ='branchLocation',
        NewValue = NEW.branchLocation,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

