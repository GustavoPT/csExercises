CREATE TRIGGER changeOnBranchDelete
  AFTER DELETE
  ON Branch
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Branch',
        columnName ='branchNum',
        oldValue = OLD.branchNum,
        Keyval1 = OLD.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Branch',
        columnName ='branchName',
        oldValue = OLD.branchName,
        Keyval1 = OLD.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Branch',
        columnName ='branchLocation',
        oldValue = OLD.branchLocation,
        Keyval1 = OLD.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
     END;

