CREATE TRIGGER changeOnBookDelete
  AFTER DELETE
  ON Book
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Book',
        columnName ='bookCode',
        Keyval1 = OLD.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Book',
        columnName ='title',
        oldValue = OLD.title,
        Keyval1 = OLD.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Book',
        columnName ='publisherCode',
        oldValue = OLD.publisherCode,
        Keyval1 = OLD.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Book',
        columnName ='type',
        oldValue = OLD.type,
        Keyval1 = OLD.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Book',
        columnName ='paperback',
        oldValue = OLD.paperback,
        Keyval1 = OLD.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
     END;

