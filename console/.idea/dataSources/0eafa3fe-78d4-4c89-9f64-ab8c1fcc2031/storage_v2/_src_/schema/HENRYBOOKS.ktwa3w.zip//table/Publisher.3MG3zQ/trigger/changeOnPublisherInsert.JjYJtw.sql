CREATE TRIGGER changeOnPublisherInsert
  AFTER INSERT
  ON Publisher
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Publisher',
        columnName ='publisherCode',
        NewValue = NEW.publisherCode,
        Keyval1 = NEW.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Publisher',
        columnName ='publisherName',
        NewValue = NEW.publisherCode,
        Keyval1 = NEW.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Publisher',
        columnName ='city',
        NewValue = NEW.city,
        Keyval1 = NEW.publisherCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

