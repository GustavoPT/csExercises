CREATE TRIGGER changeOnBookInsert
  AFTER INSERT
  ON Book
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Book',
        columnName ='bookCode',
        NewValue = NEW.bookCode,
        Keyval1 = NEW.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Book',
        columnName ='title',
        NewValue = NEW.title,
        Keyval1 = NEW.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Book',
        columnName ='publisherCode',
        NewValue = NEW.publisherCode,
        Keyval1 = NEW.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Book',
        columnName ='type',
        NewValue = NEW.type,
        Keyval1 = NEW.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Book',
        columnName ='paperback',
        NewValue = NEW.paperback,
        Keyval1 = NEW.bookCode,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
     END;

