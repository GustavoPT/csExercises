CREATE TRIGGER changeOnCopyUpdate
  AFTER UPDATE
  ON Copy
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Copy',
        columnName ='bookCode',
        oldValue = OLD.bookCode,
        NewValue = NEW.bookCode,
		Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
		tableName = 'Copy',
        columnName ='branchNum',
        oldValue = OLD.branchNum,
        NewValue = NEW.branchNum,
		Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
		tableName = 'Copy',
        columnName ='copyNum',
        oldValue = OLD.copyNum,
        NewValue = NEW.copyNum,
		Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
		tableName = 'Copy',
        columnName ='quality',
        oldValue = OLD.quality,
        NewValue = NEW.quality,
		Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
	    INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
		tableName = 'Copy',
        columnName ='price',
        oldValue = OLD.price,
        NewValue = NEW.price,
		Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

