CREATE TRIGGER changeOnInventoryInsert
  AFTER INSERT
  ON Inventory
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Inventory',
        columnName ='BookCode',
        NewValue = NEW.BookCode,
        Keyval1 = NEW.BookCode,
        Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Inventory',
        columnName ='BranchNum',
        NewValue = NEW.BranchNum,
        Keyval1 = NEW.BookCode,
        Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Branch',
        columnName ='OnHand',
        NewValue = NEW.OnHand,
        Keyval1 = NEW.BookCode,
		Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

