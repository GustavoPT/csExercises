CREATE TRIGGER changeOnBranchUpdate
  AFTER UPDATE
  ON Branch
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Branch',
        columnName ='branchNum',
        oldValue = OLD.branchNum,
        NewValue = NEW.branchNum,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Branch',
        columnName ='branchName',
        oldValue = OLD.branchName,
        NewValue = NEW.branchName,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Branch',
        columnName ='branchLocation',
        oldValue = OLD.branchLocation,
        NewValue = NEW.branchLocation,
        Keyval1 = NEW.branchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

