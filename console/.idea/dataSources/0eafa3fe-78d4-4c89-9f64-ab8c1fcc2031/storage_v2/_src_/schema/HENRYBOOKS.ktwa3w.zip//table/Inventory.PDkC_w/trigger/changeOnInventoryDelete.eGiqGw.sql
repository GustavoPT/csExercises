CREATE TRIGGER changeOnInventoryDelete
  AFTER DELETE
  ON Inventory
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Inventory',
        columnName ='BookCode',
        oldValue = OLD.BookCode,
        Keyval1 = OLD.BookCode,
        Keyval2 = OLD.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Inventory',
        columnName ='BranchNum',
        oldValue = OLD.BranchNum,
		Keyval1 = OLD.BookCode,
        Keyval2 = OLD.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Inventory',
        columnName ='OnHand',
        oldValue = OLD.OnHand,
        Keyval1 = OLD.BookCode,
		Keyval2 = OLD.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

