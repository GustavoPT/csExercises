CREATE TRIGGER changeOnWroteDelete
  AFTER DELETE
  ON Wrote
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Wrote',
        columnName ='bookCode',
        oldValue = OLD.bookCode,
        Keyval1 = OLD.bookCode,
        Keyval2 = OLD.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Wrote',
        columnName ='authorNum',
        oldValue = OLD.authorNum,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Wrote',
        columnName ='sequence',
        oldValue = OLD.sequence,
        Keyval1 = OLD.bookCode,
        Keyval2 = OLD.sequence,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

