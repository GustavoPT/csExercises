CREATE PROCEDURE spGetAllPubStatsGustavoPatino()
  begin 
	DECLARE publisherNum INT(30);

--  Stored procedure spGetAllPubStatsFL() must create a permanent 
	DROP TABLE IF EXISTS `PubStatsGustavoPatino`;
	
	CREATE TABLE  PubStatsGustavoPatino (publisherName VARCHAR(20), 
    distinctAuthors INT(20),differentBooksPublishedByPublisher INT (20), bookHighestOnHandUnitsAllBranch VARCHAR(20),
    numberOnHandUnitsForBook INT (20), cumulativeSumOnHandUnitsAllBranch INT(30));
    
    -- Loop this many times
	SET @publisherNum = (SELECT COUNT(*) publisherCode FROM Publisher);
    
    LOOPER:BEGIN
    Loopit:LOOP
				IF @publisherNum = 0 THEN LEAVE Loopit;
                END IF;
			-- the name of the publisher 
			-- the number of distinct authors who have written books for this publisher 
--             SELECT (SELECT Publisher.publisherName FROM Publisher)AS nameOfPublisher,
-- 			(SELECT COUNT(*) FROM Author INNER JOIN Wrote ON Author.authorNum = Wrote.authorNum);
            
			SELECT (SELECT Publisher.publisherName FROM Publisher) UNION
			(SELECT COUNT(*) FROM Author INNER JOIN Wrote ON Author.authorNum = Wrote.authorNum);
             -- the number of different books published by this publisher 			
			 -- The title of the book published by this publisher that has the highest number of onHand units collectively in all branches of Henry Books.
			 -- The number of onHand units for the above book.
			 -- The cumulative sum of onHand units from all branches for all books published by this publisher. 
             SET @publisherNum  = @publisherNum - 1;
		END LOOP Loopit;
    END LOOPER;

    
--  INSERT INTO PubStatsGustavoPatino ();
--  database table in which it stores the results returned by stored
--  procedure spGetPubStatsFL() for each Publisher code defined 
--  in the Publisher table. Every time spGetAllPubStatsFL() is 
--  invoked, it should clean up the permanent table before it 
--  invokes spGetPubStatsFL().

end;

