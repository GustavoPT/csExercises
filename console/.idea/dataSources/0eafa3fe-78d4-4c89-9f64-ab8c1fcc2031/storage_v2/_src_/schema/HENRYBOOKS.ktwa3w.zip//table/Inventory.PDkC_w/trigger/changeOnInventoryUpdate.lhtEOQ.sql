CREATE TRIGGER changeOnInventoryUpdate
  AFTER UPDATE
  ON Inventory
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Inventory',
        columnName ='BookCode',
        oldValue = OLD.BookCode,
        NewValue = NEW.BookCode,
        Keyval1 = NEW.BookCode,
        Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Inventory',
        columnName ='BranchNum',
        oldValue = OLD.BranchNum,
        NewValue = NEW.BranchNum,
		Keyval1 = NEW.BookCode,
        Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Branch',
        columnName ='OnHand',
        oldValue = OLD.OnHand,
        NewValue = NEW.OnHand,
        Keyval1 = NEW.BookCode,
		Keyval2 = NEW.BranchNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

