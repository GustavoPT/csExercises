CREATE TRIGGER changeOnCopyInsert
  AFTER INSERT
  ON Copy
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Copy',
        columnName ='bookCode',
        NewValue = NEW.bookCode,
        Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Copy',
        columnName ='branchNum',
        NewValue = NEW.branchNum,
        Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Copy',
        columnName ='copyNum',
        NewValue = NEW.copyNum,
        Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Copy',
        columnName ='quality',
        NewValue = NEW.quality,
        Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Copy',
        columnName ='price',
        NewValue = NEW.price,
        Keyval1 = NEW.bookCode,
        Keyval2 = NEW.branchNum,
        Keyval3 = NEW.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

