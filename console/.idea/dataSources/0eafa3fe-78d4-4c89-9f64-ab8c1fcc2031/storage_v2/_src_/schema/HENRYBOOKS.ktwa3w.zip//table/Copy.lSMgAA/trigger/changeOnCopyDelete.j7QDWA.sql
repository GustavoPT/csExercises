CREATE TRIGGER changeOnCopyDelete
  AFTER DELETE
  ON Copy
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
        tableName = 'Copy',
        columnName ='bookCode',
        oldValue = OLD.bookCode,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.branchNum,
        Keyval3 = OLD.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
		tableName = 'Copy',
        columnName ='branchNum',
        oldValue = OLD.branchNum,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.branchNum,
        Keyval3 = OLD.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
		tableName = 'Copy',
        columnName ='copyNum',
        oldValue = OLD.copyNum,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.branchNum,
        Keyval3 = OLD.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
		tableName = 'Copy',
        columnName ='quality',
        oldValue = OLD.quality,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.branchNum,
        Keyval3 = OLD.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
	    INSERT INTO HistoricalAudit
        SET Action = 'DELETE',
		tableName = 'Copy',
        columnName ='price',
        oldValue = OLD.price,
		Keyval1 = OLD.bookCode,
        Keyval2 = OLD.branchNum,
        Keyval3 = OLD.copyNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

