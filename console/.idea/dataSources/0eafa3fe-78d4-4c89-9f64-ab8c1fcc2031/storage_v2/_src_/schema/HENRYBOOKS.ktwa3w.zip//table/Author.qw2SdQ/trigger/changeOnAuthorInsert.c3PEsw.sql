CREATE TRIGGER changeOnAuthorInsert
  AFTER INSERT
  ON Author
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Author',
        columnName ='authorNum',
        NewValue = NEW.authorNum,
        Keyval1 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Author',
        columnName ='authorLast',
        NewValue = NEW.authorLast,
        Keyval1 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Author',
        columnName ='authorFirst',
        NewValue = NEW.authorFirst,
        Keyval1 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
     END;

