CREATE PROCEDURE caller()
  begin 
	CALL spGetAllPubStatsGustavoPatino();
-- 	SELECT * FROM @a;
end;

