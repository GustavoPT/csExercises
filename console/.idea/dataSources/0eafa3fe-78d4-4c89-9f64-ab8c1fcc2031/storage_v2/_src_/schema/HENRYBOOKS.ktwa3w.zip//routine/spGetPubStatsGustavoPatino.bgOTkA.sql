CREATE PROCEDURE spGetPubStatsGustavoPatino(IN pubCode CHAR(3))
  BEGIN
    SELECT publisherName FROM Publisher WHERE publisherCode = pubCode;
    SELECT * FROM Author INNER JOIN(
    (SELECT * FROM Book INNER JOIN Wrote) AS Book_Wrote)
    WHERE 'JP' = Book_Wrote.pubCode;

	END;

