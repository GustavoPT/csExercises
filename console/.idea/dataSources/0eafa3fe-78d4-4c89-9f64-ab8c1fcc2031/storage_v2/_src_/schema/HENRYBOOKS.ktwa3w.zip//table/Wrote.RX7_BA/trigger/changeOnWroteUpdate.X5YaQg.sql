CREATE TRIGGER changeOnWroteUpdate
  AFTER UPDATE
  ON Wrote
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Wrote',
        columnName ='bookCode',
        oldValue = OLD.bookCode,
        NewValue = NEW.bookCode,
        Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Wrote',
        columnName ='authorNum',
        oldValue = OLD.authorNum,
        NewValue = NEW.authorNum,
		Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'UPDATE',
        tableName = 'Wrote',
        columnName ='sequence',
        oldValue = OLD.sequence,
        NewValue = NEW.bookCode,
		Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

