CREATE TRIGGER changeOnAuthorDelete
  AFTER DELETE
  ON Author
  FOR EACH ROW
  BEGIN 
				INSERT INTO HistoricalAudit
				SET Action = 'DELETE',
				tableName = 'Author',
				columnName ='authorNum',
                Keyval1  = Old.authorNum,
                oldValue = Old.authorNum,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
				
				INSERT INTO HistoricalAudit
				SET Action = 'DELETE',
				tableName = 'Author',
				columnName ='authorLast',
                Keyval1 = Old.authorNum,
                oldValue = Old.authorLast,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
				
				INSERT INTO HistoricalAudit
				SET Action = 'DELETE',
				tableName = 'Author',
				columnName ='authorFirst',
				Keyval1 = Old.authorNum,
                oldValue = Old.authorFirst,
				UserId = CURRENT_USER(),
				logTimeStamp = CURRENT_TIMESTAMP();
     END;

