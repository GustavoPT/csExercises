CREATE TRIGGER changeOnWroteInsert
  AFTER INSERT
  ON Wrote
  FOR EACH ROW
  BEGIN 
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Wrote',
        columnName ='bookCode',
        NewValue = NEW.bookCode,
        Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Wrote',
        columnName ='authorNum',
        NewValue = NEW.authorNum,
        Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
		INSERT INTO HistoricalAudit
        SET Action = 'INSERT',
        tableName = 'Wrote',
        columnName ='sequence',
        NewValue = NEW.sequence,
        Keyval1 = NEW.bookCode,
		Keyval2 = NEW.authorNum,
        UserId = CURRENT_USER(),
        logTimeStamp = CURRENT_TIMESTAMP();
        
     END;

