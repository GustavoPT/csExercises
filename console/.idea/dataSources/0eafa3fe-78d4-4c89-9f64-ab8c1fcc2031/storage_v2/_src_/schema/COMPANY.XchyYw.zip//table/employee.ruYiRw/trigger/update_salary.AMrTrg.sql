CREATE TRIGGER update_salary
  AFTER INSERT
  ON employee
  FOR EACH ROW
  BEGIN 
			iF new.dno IS NOT NULL THEN 
				UPDATE deptsal
				SET totalSalary = totalSalary + new.salary
				WHERE dnumber = new.dno;
			end if;
		END;

