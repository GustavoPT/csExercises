CREATE PROCEDURE updateSalary()
  begin 
	declare done int default 0;
    declare current_dnum int;
    declare dnumcur cursor for select dnumber from deptsal;
    declare continue handler for not found set done = 1;
    
    open dnumcur;
    
    repeat 
      fetch dnumcur into current_dnum;
      update deptsal
      set totalsalary = (SELECT sum(salary) from employee 
		WHERE dno = current_dnum)
	 WHERE dnumber = current_dnum;
     until done
     end repeat;
     
     close dnumcur;

end;

