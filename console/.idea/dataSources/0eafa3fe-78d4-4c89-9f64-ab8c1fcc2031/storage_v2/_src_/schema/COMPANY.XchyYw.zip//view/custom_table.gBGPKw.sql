CREATE VIEW custom_table AS
  SELECT `company`.`employee`.`fname` AS `Fname`
  FROM `company`.`employee`;

