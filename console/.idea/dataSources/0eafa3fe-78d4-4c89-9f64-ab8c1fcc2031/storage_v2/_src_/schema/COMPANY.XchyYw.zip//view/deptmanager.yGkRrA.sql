CREATE VIEW deptmanager AS
  SELECT
    `company`.`employee`.`fname`     AS `fname`,
    `company`.`employee`.`lname`     AS `lname`,
    `company`.`department`.`dname`   AS `dname`,
    `company`.`department`.`dnumber` AS `dnumber`
  FROM `company`.`employee`
    JOIN `company`.`department`
  WHERE ((`company`.`employee`.`ssn` = `company`.`department`.`mgrssn`) AND
         (`company`.`employee`.`dno` = `company`.`department`.`dnumber`));

