CREATE VIEW manager AS
  SELECT
    `company`.`employee`.`fname`     AS `FNAME`,
    `company`.`employee`.`lname`     AS `LNAME`,
    `company`.`department`.`dname`   AS `DName`,
    `company`.`department`.`dnumber` AS `Dnumber`,
    `company`.`employee`.`salary`    AS `SALARY`
  FROM `company`.`employee`
    JOIN `company`.`department`
  WHERE ((`company`.`employee`.`ssn` = `company`.`department`.`mgrssn`) AND
         (`company`.`employee`.`dno` = `company`.`department`.`dnumber`));

