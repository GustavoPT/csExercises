CREATE VIEW custom_table1 AS
  SELECT
    `company`.`employee`.`fname` AS `Fname`,
    `company`.`employee`.`lname` AS `lname`
  FROM `company`.`employee`;

